import sys

print(sys.version)

#uwaga na ścieżki przy starcie - obie mają się zgadzać
#file-settings-version control-github-add-zaloguj się w przeglądarce
#git config --list
#git config --global user.name s175012
#git config --global user.email 147266485+s175012@users.noreply.github.com
#vcs-share on github

a = 5
print(a)

#git-commit albo ptak z gita albo ctrl+k
#git-push albo strzała z gita albo ctrl+shift+k
#na koniec odłącz konto i skasuj poświadczenie do gita z menedżera poświadczeń

import this
